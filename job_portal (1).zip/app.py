import streamlit as st
import pandas as pd
import sqlite3
import hashlib
import os
from datetime import datetime

# Set page configuration
st.set_page_config(
    page_title="Job Portal",
    page_icon="💼",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize the database
def init_db():
    # Create database connection
    conn = sqlite3.connect('job_portal.db', check_same_thread=False)
    c = conn.cursor()
    
    # Create tables if they don't exist
    
    # Users table
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        full_name TEXT NOT NULL,
        user_type TEXT NOT NULL,
        resume TEXT,
        skills TEXT,
        experience TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Jobs table
    c.execute('''
    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        location TEXT NOT NULL,
        description TEXT NOT NULL,
        requirements TEXT NOT NULL,
        salary TEXT,
        posted_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'active'
    )
    ''')
    
    # Applications table
    c.execute('''
    CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        cover_letter TEXT,
        status TEXT DEFAULT 'pending',
        applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (job_id) REFERENCES jobs (id),
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    ''')
    
    # Create admin user if not exists
    c.execute("SELECT * FROM users WHERE username='admin'")
    if not c.fetchone():
        hashed_password = hashlib.sha256("admin123".encode()).hexdigest()
        c.execute("INSERT INTO users (username, password, email, full_name, user_type) VALUES (?, ?, ?, ?, ?)",
                  ('admin', hashed_password, 'admin@jobportal.com', 'Admin User', 'admin'))
    
    # Insert sample jobs if the table is empty
    c.execute("SELECT COUNT(*) FROM jobs")
    if c.fetchone()[0] == 0:
        sample_jobs = [
            ('Software Engineer', 'Tech Solutions Inc.', 'San Francisco, CA', 
             'Developing and maintaining software applications.', 
             'Bachelor\'s degree in Computer Science, 3+ years of experience in software development.', 
             '$100,000 - $130,000'),
            ('Data Scientist', 'Data Insights Corp', 'New York, NY', 
             'Analyze complex data sets to find patterns and insights.', 
             'Master\'s degree in Statistics or related field, experience with Python and R.', 
             '$120,000 - $150,000'),
            ('UX Designer', 'Creative Designs', 'Austin, TX', 
             'Creating user-centered designs for web and mobile applications.', 
             'Portfolio demonstrating UX design skills, experience with design tools like Figma.', 
             '$90,000 - $110,000'),
            ('Marketing Manager', 'Global Marketing', 'Chicago, IL', 
             'Developing and implementing marketing strategies.', 
             'Bachelor\'s degree in Marketing, 5+ years of experience in marketing roles.', 
             '$80,000 - $100,000'),
            ('Project Manager', 'Project Solutions', 'Seattle, WA', 
             'Leading and coordinating projects from initiation to completion.', 
             'PMP certification, 5+ years of project management experience.', 
             '$95,000 - $120,000')
        ]
        
        c.executemany('''
        INSERT INTO jobs (title, company, location, description, requirements, salary)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', sample_jobs)
    
    conn.commit()
    return conn

# Password hashing function
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Authentication functions
def login_user(username, password):
    conn = init_db()
    c = conn.cursor()
    hashed_password = hash_password(password)
    c.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, hashed_password))
    user = c.fetchone()
    if user:
        return {
            'id': user[0],
            'username': user[1],
            'email': user[3],
            'full_name': user[4],
            'user_type': user[5],
            'resume': user[6],
            'skills': user[7],
            'experience': user[8]
        }
    return None

def register_user(username, password, email, full_name, user_type, resume=None, skills=None, experience=None):
    conn = init_db()
    c = conn.cursor()
    try:
        hashed_password = hash_password(password)
        c.execute('''
        INSERT INTO users (username, password, email, full_name, user_type, resume, skills, experience)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (username, hashed_password, email, full_name, user_type, resume, skills, experience))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False

# Job functions
def get_all_jobs():
    conn = init_db()
    return pd.read_sql("SELECT * FROM jobs WHERE status='active' ORDER BY posted_date DESC", conn)

def get_job_by_id(job_id):
    conn = init_db()
    return pd.read_sql("SELECT * FROM jobs WHERE id=?", conn, params=(job_id,))

def search_jobs(query):
    conn = init_db()
    search_term = f"%{query}%"
    return pd.read_sql('''
    SELECT * FROM jobs 
    WHERE (title LIKE ? OR company LIKE ? OR description LIKE ? OR requirements LIKE ?) AND status='active'
    ORDER BY posted_date DESC
    ''', conn, params=(search_term, search_term, search_term, search_term))

def add_job(title, company, location, description, requirements, salary):
    conn = init_db()
    c = conn.cursor()
    c.execute('''
    INSERT INTO jobs (title, company, location, description, requirements, salary)
    VALUES (?, ?, ?, ?, ?, ?)
    ''', (title, company, location, description, requirements, salary))
    conn.commit()

def delete_job(job_id):
    conn = init_db()
    c = conn.cursor()
    c.execute("UPDATE jobs SET status='inactive' WHERE id=?", (job_id,))
    conn.commit()

# Application functions
def apply_for_job(job_id, user_id, cover_letter):
    conn = init_db()
    c = conn.cursor()
    
    # Check if already applied
    c.execute("SELECT * FROM applications WHERE job_id=? AND user_id=?", (job_id, user_id))
    if c.fetchone():
        return False
    
    c.execute('''
    INSERT INTO applications (job_id, user_id, cover_letter)
    VALUES (?, ?, ?)
    ''', (job_id, user_id, cover_letter))
    conn.commit()
    return True

def get_user_applications(user_id):
    conn = init_db()
    return pd.read_sql('''
    SELECT a.id, a.status, a.applied_date, j.title, j.company, j.location
    FROM applications a
    JOIN jobs j ON a.job_id = j.id
    WHERE a.user_id = ?
    ORDER BY a.applied_date DESC
    ''', conn, params=(user_id,))

def get_all_applications():
    conn = init_db()
    return pd.read_sql('''
    SELECT a.id, a.status, a.applied_date, j.title, j.company, u.full_name, u.email
    FROM applications a
    JOIN jobs j ON a.job_id = j.id
    JOIN users u ON a.user_id = u.id
    ORDER BY a.applied_date DESC
    ''', conn)

def get_application_details(app_id):
    conn = init_db()
    application = pd.read_sql('''
    SELECT a.*, j.title, j.company, j.description, j.requirements, 
           u.full_name, u.email, u.resume, u.skills, u.experience
    FROM applications a
    JOIN jobs j ON a.job_id = j.id
    JOIN users u ON a.user_id = u.id
    WHERE a.id = ?
    ''', conn, params=(app_id,))
    
    if not application.empty:
        return application.iloc[0]
    return None

def update_application_status(app_id, status):
    conn = init_db()
    c = conn.cursor()
    c.execute("UPDATE applications SET status=? WHERE id=?", (status, app_id))
    conn.commit()

def get_all_job_seekers():
    conn = init_db()
    return pd.read_sql('''
    SELECT id, username, email, full_name, resume, skills, experience, created_at
    FROM users
    WHERE user_type='job_seeker'
    ORDER BY created_at DESC
    ''', conn)

# Main application
def main():
    # Initialize session state variables if they don't exist
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'user' not in st.session_state:
        st.session_state.user = None
    if 'page' not in st.session_state:
        st.session_state.page = 'login'
    
    # Initialize the database
    conn = init_db()
    
    # Sidebar navigation
    with st.sidebar:
        st.title("Job Portal")
        
        if st.session_state.logged_in:
            st.write(f"Logged in as: {st.session_state.user['full_name']}")
            
            if st.session_state.user['user_type'] == 'admin':
                if st.button("Dashboard"):
                    st.session_state.page = 'admin_dashboard'
                if st.button("Manage Jobs"):
                    st.session_state.page = 'manage_jobs'
                if st.button("View Applications"):
                    st.session_state.page = 'admin_applications'
                if st.button("View Job Seekers"):
                    st.session_state.page = 'view_job_seekers'
            else:
                if st.button("Browse Jobs"):
                    st.session_state.page = 'browse_jobs'
                if st.button("My Applications"):
                    st.session_state.page = 'my_applications'
                if st.button("Profile"):
                    st.session_state.page = 'profile'
            
            if st.button("Logout"):
                st.session_state.logged_in = False
                st.session_state.user = None
                st.session_state.page = 'login'
                st.rerun()
        else:
            if st.button("Login"):
                st.session_state.page = 'login'
            if st.button("Register"):
                st.session_state.page = 'register'
    
    # Main content
    if not st.session_state.logged_in:
        if st.session_state.page == 'login':
            display_login_page()
        elif st.session_state.page == 'register':
            display_register_page()
    else:
        # Admin pages
        if st.session_state.user['user_type'] == 'admin':
            if st.session_state.page == 'admin_dashboard':
                display_admin_dashboard()
            elif st.session_state.page == 'manage_jobs':
                display_manage_jobs()
            elif st.session_state.page == 'admin_applications':
                display_admin_applications()
            elif st.session_state.page == 'view_job_seekers':
                display_job_seekers()
            elif st.session_state.page == 'view_application':
                display_application_details()
        # Job seeker pages
        else:
            if st.session_state.page == 'browse_jobs':
                display_browse_jobs()
            elif st.session_state.page == 'job_details':
                display_job_details()
            elif st.session_state.page == 'my_applications':
                display_my_applications()
            elif st.session_state.page == 'profile':
                display_profile()

# Page display functions
def display_login_page():
    st.title("Login")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        
        if st.button("Login"):
            if not username or not password:
                st.error("Please enter both username and password")
            else:
                user = login_user(username, password)
                if user:
                    st.session_state.logged_in = True
                    st.session_state.user = user
                    
                    if user['user_type'] == 'admin':
                        st.session_state.page = 'admin_dashboard'
                    else:
                        st.session_state.page = 'browse_jobs'
                    
                    st.success("Login successful!")
                    st.rerun()
                else:
                    st.error("Invalid username or password")

def display_register_page():
    st.title("Register")
    
    tab1, tab2 = st.tabs(["Job Seeker", "Admin"])
    
    with tab1:
        with st.form("job_seeker_registration"):
            st.subheader("Register as a Job Seeker")
            
            full_name = st.text_input("Full Name")
            email = st.text_input("Email")
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            confirm_password = st.text_input("Confirm Password", type="password")
            
            resume = st.text_area("Resume", help="Paste your resume text here")
            skills = st.text_area("Skills", help="List your key skills")
            experience = st.text_area("Experience", help="Describe your work experience")
            
            submit_button = st.form_submit_button("Register")
            
            if submit_button:
                if not full_name or not email or not username or not password or not confirm_password:
                    st.error("Please fill in all required fields")
                elif password != confirm_password:
                    st.error("Passwords do not match")
                else:
                    if register_user(username, password, email, full_name, 'job_seeker', resume, skills, experience):
                        st.success("Registration successful! You can now login.")
                        st.session_state.page = 'login'
                        st.rerun()
                    else:
                        st.error("Username or email already exists")
    
    with tab2:
        with st.form("admin_registration"):
            st.subheader("Register as an Admin")
            
            admin_full_name = st.text_input("Admin Full Name")
            admin_email = st.text_input("Admin Email")
            admin_username = st.text_input("Admin Username")
            admin_password = st.text_input("Admin Password", type="password")
            admin_confirm_password = st.text_input("Confirm Admin Password", type="password")
            admin_secret_key = st.text_input("Admin Secret Key", type="password", 
                                            help="Contact system administrator for the secret key")
            
            admin_submit_button = st.form_submit_button("Register as Admin")
            
            if admin_submit_button:
                if not admin_full_name or not admin_email or not admin_username or not admin_password or not admin_confirm_password:
                    st.error("Please fill in all required fields")
                elif admin_password != admin_confirm_password:
                    st.error("Passwords do not match")
                elif admin_secret_key != "admin_secret":  # Simple example, this should be more secure in practice
                    st.error("Invalid admin secret key")
                else:
                    if register_user(admin_username, admin_password, admin_email, admin_full_name, 'admin'):
                        st.success("Admin registration successful! You can now login.")
                        st.session_state.page = 'login'
                        st.rerun()
                    else:
                        st.error("Username or email already exists")

def display_admin_dashboard():
    st.title("Admin Dashboard")
    
    # Get database statistics
    conn = init_db()
    c = conn.cursor()
    
    c.execute("SELECT COUNT(*) FROM users WHERE user_type='job_seeker'")
    job_seekers_count = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM jobs WHERE status='active'")
    active_jobs_count = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM applications WHERE status='pending'")
    pending_applications_count = c.fetchone()[0]
    
    c.execute("SELECT COUNT(*) FROM applications")
    total_applications_count = c.fetchone()[0]
    
    # Display statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Job Seekers", job_seekers_count)
    
    with col2:
        st.metric("Active Jobs", active_jobs_count)
    
    with col3:
        st.metric("Pending Applications", pending_applications_count)
    
    with col4:
        st.metric("Total Applications", total_applications_count)
    
    # Recent applications
    st.subheader("Recent Applications")
    recent_applications = pd.read_sql('''
    SELECT a.id, a.status, a.applied_date, j.title, j.company, u.full_name
    FROM applications a
    JOIN jobs j ON a.job_id = j.id
    JOIN users u ON a.user_id = u.id
    ORDER BY a.applied_date DESC
    LIMIT 5
    ''', conn)
    
    if not recent_applications.empty:
        st.dataframe(recent_applications)
    else:
        st.info("No applications yet")
    
    # Recent job seekers
    st.subheader("Recent Job Seekers")
    recent_users = pd.read_sql('''
    SELECT id, full_name, email, created_at
    FROM users
    WHERE user_type='job_seeker'
    ORDER BY created_at DESC
    LIMIT 5
    ''', conn)
    
    if not recent_users.empty:
        st.dataframe(recent_users)
    else:
        st.info("No job seekers yet")

def display_manage_jobs():
    st.title("Manage Jobs")
    
    tab1, tab2 = st.tabs(["Add New Job", "View/Edit Jobs"])
    
    with tab1:
        with st.form("add_job_form"):
            st.subheader("Add New Job")
            
            job_title = st.text_input("Job Title")
            company = st.text_input("Company Name")
            location = st.text_input("Location")
            salary = st.text_input("Salary Range")
            description = st.text_area("Job Description")
            requirements = st.text_area("Job Requirements")
            
            submit_button = st.form_submit_button("Add Job")
            
            if submit_button:
                if not job_title or not company or not location or not description or not requirements:
                    st.error("Please fill in all required fields")
                else:
                    add_job(job_title, company, location, description, requirements, salary)
                    st.success("Job added successfully!")
    
    with tab2:
        st.subheader("Existing Jobs")
        
        jobs = get_all_jobs()
        if not jobs.empty:
            for _, job in jobs.iterrows():
                with st.expander(f"{job['title']} at {job['company']}"):
                    st.write(f"**Location:** {job['location']}")
                    st.write(f"**Salary:** {job['salary']}")
                    st.write(f"**Posted:** {job['posted_date']}")
                    st.write("**Description:**")
                    st.write(job['description'])
                    st.write("**Requirements:**")
                    st.write(job['requirements'])
                    
                    if st.button(f"Delete Job #{job['id']}", key=f"delete_{job['id']}"):
                        delete_job(job['id'])
                        st.success("Job deleted successfully!")
                        st.rerun()
        else:
            st.info("No jobs available")

def display_admin_applications():
    st.title("Job Applications")
    
    # Filter options
    filter_status = st.selectbox("Filter by Status", ["All", "Pending", "Approved", "Rejected"])
    
    # Get applications with filter
    applications = get_all_applications()
    
    if filter_status != "All":
        applications = applications[applications['status'].str.lower() == filter_status.lower()]
    
    if not applications.empty:
        st.dataframe(applications)
        
        # View application details
        app_id = st.number_input("Enter Application ID to view details", min_value=1, step=1)
        if st.button("View Application"):
            st.session_state.selected_app_id = app_id
            st.session_state.page = 'view_application'
            st.rerun()
    else:
        st.info("No applications found")

def display_application_details():
    if 'selected_app_id' in st.session_state:
        app_id = st.session_state.selected_app_id
        application = get_application_details(app_id)
        
        if application is not None:
            st.title(f"Application #{app_id} - {application['title']} at {application['company']}")
            
            # Display status with color
            status = application['status']
            if status == 'pending':
                st.info(f"Status: {status.upper()}")
            elif status == 'approved':
                st.success(f"Status: {status.upper()}")
            elif status == 'rejected':
                st.error(f"Status: {status.upper()}")
            
            # Application details
            st.subheader("Application Details")
            st.write(f"**Applied on:** {application['applied_date']}")
            
            # Job details
            st.subheader("Job Details")
            st.write(f"**Title:** {application['title']}")
            st.write(f"**Company:** {application['company']}")
            st.write(f"**Description:** {application['description']}")
            st.write(f"**Requirements:** {application['requirements']}")
            
            # Applicant details
            st.subheader("Applicant Details")
            st.write(f"**Name:** {application['full_name']}")
            st.write(f"**Email:** {application['email']}")
            st.write(f"**Skills:** {application['skills']}")
            st.write(f"**Experience:** {application['experience']}")
            
            # Resume
            st.subheader("Resume")
            st.text_area("", application['resume'], height=200, disabled=True)
            
            # Cover letter
            st.subheader("Cover Letter")
            st.text_area("", application['cover_letter'], height=200, disabled=True)
            
            # Update status
            if application['status'] == 'pending':
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Approve Application"):
                        update_application_status(app_id, 'approved')
                        st.success("Application approved!")
                        st.rerun()
                with col2:
                    if st.button("Reject Application"):
                        update_application_status(app_id, 'rejected')
                        st.error("Application rejected!")
                        st.rerun()
            
            if st.button("Back to Applications"):
                st.session_state.page = 'admin_applications'
                st.rerun()
        else:
            st.error("Application not found")
            if st.button("Back"):
                st.session_state.page = 'admin_applications'
                st.rerun()

def display_job_seekers():
    st.title("Job Seekers")
    
    job_seekers = get_all_job_seekers()
    
    if not job_seekers.empty:
        st.dataframe(job_seekers)
        
        # Select a job seeker to view details
        selected_id = st.selectbox("Select a job seeker to view details", job_seekers['id'])
        selected_user = job_seekers[job_seekers['id'] == selected_id].iloc[0]
        
        with st.expander("Job Seeker Details", expanded=True):
            st.write(f"**Name:** {selected_user['full_name']}")
            st.write(f"**Email:** {selected_user['email']}")
            st.write(f"**Username:** {selected_user['username']}")
            
            st.subheader("Resume")
            st.text_area("", selected_user['resume'], height=200, disabled=True)
            
            st.subheader("Skills")
            st.text_area("", selected_user['skills'], height=100, disabled=True)
            
            st.subheader("Experience")
            st.text_area("", selected_user['experience'], height=150, disabled=True)
            
            # Get user's applications
            conn = init_db()
            user_apps = pd.read_sql('''
            SELECT a.id, a.status, a.applied_date, j.title, j.company
            FROM applications a
            JOIN jobs j ON a.job_id = j.id
            WHERE a.user_id = ?
            ORDER BY a.applied_date DESC
            ''', conn, params=(selected_id,))
            
            st.subheader("Applications")
            if not user_apps.empty:
                st.dataframe(user_apps)
            else:
                st.info("No applications submitted yet")
    else:
        st.info("No job seekers registered yet")

def display_browse_jobs():
    st.title("Browse Jobs")
    
    # Search box
    search_query = st.text_input("Search for jobs", value="")
    
    if search_query:
        jobs = search_jobs(search_query)
    else:
        jobs = get_all_jobs()
    
    # Display jobs
    if not jobs.empty:
        st.write(f"Showing {len(jobs)} jobs")
        
        for _, job in jobs.iterrows():
            with st.container():
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.subheader(job['title'])
                    st.write(f"{job['company']} • {job['location']}")
                    
                    if job['salary']:
                        st.write(f"**Salary:** {job['salary']}")
                    
                    st.write("**Description:**")
                    st.write(job['description'][:150] + "..." if len(job['description']) > 150 else job['description'])
                
                with col2:
                    st.write("")
                    st.write("")
                    if st.button("View Details", key=f"view_{job['id']}"):
                        st.session_state.selected_job_id = job['id']
                        st.session_state.page = 'job_details'
                        st.rerun()
                
                st.divider()
    else:
        st.info("No jobs found matching your search criteria")

def display_job_details():
    if 'selected_job_id' in st.session_state:
        job_id = st.session_state.selected_job_id
        job = get_job_by_id(job_id)
        
        if not job.empty:
            job = job.iloc[0]
            
            st.title(job['title'])
            st.subheader(f"{job['company']} • {job['location']}")
            
            if job['salary']:
                st.write(f"**Salary:** {job['salary']}")
            
            st.write(f"**Posted:** {job['posted_date']}")
            
            st.subheader("Job Description")
            st.write(job['description'])
            
            st.subheader("Requirements")
            st.write(job['requirements'])
            
            # Check if already applied
            conn = init_db()
            c = conn.cursor()
            c.execute("SELECT * FROM applications WHERE job_id=? AND user_id=?", 
                     (job_id, st.session_state.user['id']))
            already_applied = c.fetchone() is not None
            
            if already_applied:
                st.success("You have already applied for this job!")
            else:
                st.subheader("Apply for this job")
                with st.form("job_application_form"):
                    cover_letter = st.text_area("Cover Letter", 
                                               help="Explain why you're a good fit for this role")
                    
                    submitted = st.form_submit_button("Submit Application")
                    if submitted:
                        if not cover_letter:
                            st.error("Please provide a cover letter")
                        else:
                            if apply_for_job(job_id, st.session_state.user['id'], cover_letter):
                                st.success("Application submitted successfully!")
                                st.rerun()
                            else:
                                st.error("Failed to submit application. You may have already applied for this job.")
            
            if st.button("Back to Job Listings"):
                st.session_state.page = 'browse_jobs'
                st.rerun()
        else:
            st.error("Job not found")
            if st.button("Back to Jobs"):
                st.session_state.page = 'browse_jobs'
                st.rerun()

def display_my_applications():
    st.title("My Applications")
    
    applications = get_user_applications(st.session_state.user['id'])
    
    if not applications.empty:
        for _, app in applications.iterrows():
            with st.container():
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.subheader(app['title'])
                    st.write(f"{app['company']} • {app['location']}")
                    st.write(f"Applied on: {app['applied_date']}")
                
                with col2:
                    st.write("")
                    st.write("")
                    if app['status'] == 'pending':
                        st.info(f"Status: {app['status'].upper()}")
                    elif app['status'] == 'approved':
                        st.success(f"Status: {app['status'].upper()}")
                    elif app['status'] == 'rejected':
                        st.error(f"Status: {app['status'].upper()}")
                
                st.divider()
    else:
        st.info("You haven't applied for any jobs yet.")
        
        if st.button("Browse Jobs"):
            st.session_state.page = 'browse_jobs'
            st.rerun()

def display_profile():
    st.title("My Profile")
    
    user = st.session_state.user
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("Personal Information")
        st.write(f"**Name:** {user['full_name']}")
        st.write(f"**Email:** {user['email']}")
        st.write(f"**Username:** {user['username']}")
    
    with st.form("update_profile"):
        st.subheader("Update Profile")
        
        resume = st.text_area("Resume", value=user['resume'] or "")
        skills = st.text_area("Skills", value=user['skills'] or "")
        experience = st.text_area("Experience", value=user['experience'] or "")
        
        update_button = st.form_submit_button("Update Profile")
        
        if update_button:
            conn = init_db()
            c = conn.cursor()
            c.execute('''
            UPDATE users
            SET resume=?, skills=?, experience=?
            WHERE id=?
            ''', (resume, skills, experience, user['id']))
            conn.commit()
            
            # Update session state
            st.session_state.user['resume'] = resume
            st.session_state.user['skills'] = skills
            st.session_state.user['experience'] = experience
            
            st.success("Profile updated successfully!")
            st.rerun()

if __name__ == "__main__":
    main()
