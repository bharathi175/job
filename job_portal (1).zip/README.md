# Job Portal Application

A Python-based online job portal with user and admin functionality built using Streamlit.

## Features

- **User Authentication**:
  - Login and registration for both job seekers and admins
  - Secure password storage (hashed)

- **Job Seeker Features**:
  - Search and browse available jobs
  - Apply for jobs with cover letters
  - Track application status
  - Update personal profile and resume

- **Admin Features**:
  - Dashboard with key statistics
  - Manage job listings (add/remove)
  - Review and process job applications
  - View job seeker profiles

## Setup and Installation

1. Make sure you have Python installed (version 3.7 or higher)

2. Install the required dependencies:
   ```
   pip install streamlit pandas
   ```

3. Run the application:
   ```
   streamlit run app.py
   ```

## Database

The application uses SQLite for data storage with three main tables:
- Users: Storing user information and credentials
- Jobs: Job listings and their details
- Applications: Tracking job applications and their status

## Default Admin Access

A default admin account is created on first run:
- **Username**: admin
- **Password**: admin123

## Initial Sample Data

The database is pre-populated with sample job listings to help you get started quickly.