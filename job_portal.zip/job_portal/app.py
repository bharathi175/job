import streamlit as st
import sqlite3

# DB functions
def create_tables():
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE,
                    password TEXT,
                    role TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT,
                    description TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS applications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    job_id INTEGER,
                    status TEXT,
                    FOREIGN KEY(user_id) REFERENCES users(id),
                    FOREIGN KEY(job_id) REFERENCES jobs(id))''')
    conn.commit()
    conn.close()

def register_user(username, password, role):
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", (username, password, role))
        conn.commit()
        st.success("User registered successfully!")
    except sqlite3.IntegrityError:
        st.error("Username already exists.")
    conn.close()

def login_user(username, password):
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    result = c.fetchone()
    conn.close()
    return result

def add_job(title, description):
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute("INSERT INTO jobs (title, description) VALUES (?, ?)", (title, description))
    conn.commit()
    conn.close()

def get_jobs():
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute("SELECT * FROM jobs")
    jobs = c.fetchall()
    conn.close()
    return jobs

def apply_for_job(user_id, job_id):
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute("INSERT INTO applications (user_id, job_id, status) VALUES (?, ?, 'Pending')", (user_id, job_id))
    conn.commit()
    conn.close()

def get_applications():
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute('''SELECT applications.id, users.username, jobs.title, applications.status
                 FROM applications
                 JOIN users ON applications.user_id = users.id
                 JOIN jobs ON applications.job_id = jobs.id''')
    apps = c.fetchall()
    conn.close()
    return apps

def update_application_status(app_id, status):
    conn = sqlite3.connect('job_portal.db')
    c = conn.cursor()
    c.execute("UPDATE applications SET status=? WHERE id=?", (status, app_id))
    conn.commit()
    conn.close()

# Streamlit App
def main():
    st.title("🧑‍💼 Online Job Portal")
    menu = ["Login", "Register"]
    choice = st.sidebar.selectbox("Menu", menu)

    create_tables()

    if choice == "Register":
        st.subheader("Register")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        role = st.selectbox("Role", ["jobseeker", "admin"])
        if st.button("Register"):
            register_user(username, password, role)

    elif choice == "Login":
        st.subheader("Login")
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.button("Login"):
            user = login_user(username, password)
            if user:
                st.success(f"Logged in as {user[1]} ({user[3]})")
                if user[3] == "admin":
                    admin_panel(user)
                else:
                    job_seeker_panel(user)
            else:
                st.error("Invalid Credentials")

def admin_panel(user):
    st.subheader("Admin Panel")
    st.write("Welcome, Admin!")
    tab1, tab2 = st.tabs(["Add Job", "Manage Applications"])

    with tab1:
        title = st.text_input("Job Title")
        description = st.text_area("Job Description")
        if st.button("Add Job"):
            add_job(title, description)
            st.success("Job added successfully.")

    with tab2:
        st.write("Applications:")
        applications = get_applications()
        for app in applications:
            st.write(f"ID: {app[0]} | User: {app[1]} | Job: {app[2]} | Status: {app[3]}")
            if app[3] == "Pending":
                col1, col2 = st.columns(2)
                with col1:
                    if st.button(f"Accept {app[0]}"):
                        update_application_status(app[0], "Accepted")
                with col2:
                    if st.button(f"Reject {app[0]}"):
                        update_application_status(app[0], "Rejected")

def job_seeker_panel(user):
    st.subheader("Job Seeker Panel")
    st.write("Available Jobs:")
    jobs = get_jobs()
    for job in jobs:
        st.write(f"ID: {job[0]} | Title: {job[1]} | Description: {job[2]}")
        if st.button(f"Apply for {job[0]}"):
            apply_for_job(user[0], job[0])
            st.success("Application submitted.")

if __name__ == '__main__':
    main()
